cp omovelog.txt imovelog.txt
echo "omovelog copied to imovelog"
