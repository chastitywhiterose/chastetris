Chaste Tris Music License

The only thing in Chaste Tris that is not my creation is the music which was obtained freely from OverClocked ReMix.

According to my understanding of the terms in the FAQ I am allowed to use the songs as long as I give credit to OC Remix and the artists. As such, I intend to mention them in every video I create showing the gameplay with the newly added music. In fact, if I have not included credit anywhere it is most likely a technical limitation such as Tiktok or Instagram not allowing me to add long descriptions. But where possible I will give credit to the artists and OC ReMix.

Also I may forget to add credits while I am uploading demo videos to multiple sites but as soon as I get comments asking me where the songs are from I will be able to edit the videos and add the proper credits.

Both of these songs are remixes of the songs originally included in Gameboy Tetris. They are as follows.

OverClocked ReMix

ReMix:Tetris "Gift from Moscow"
By MkVaff

https://ocremix.org/remix/OCR00826

ReMix:Tetris "T-Spin"
By Schtiffles

https://ocremix.org/remix/OCR04112

These two songs were chosen precisely because they fit in with the dream I had for the game considering that it is a Tetris game, and the Gameboy version was probably the most popular version of all time and the only one many people were even exposed to in the 80s.

As a third addition, I have selected another arrangement by MkVaff because it's fast dance nature feels amazing even though it is from a game known as Chrono Trigger for SNES I played years ago.

ReMix:Chrono Trigger "Protector in Green"
By MkVaff

https://ocremix.org/remix/OCR04367

I have also considered including a remix of Dance of the Sugarplum Fairy if I can find one that sounds good that I can use with permission. If you know of one, please let me know.
